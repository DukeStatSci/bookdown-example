# README original data

Data are from dplyr::starwars